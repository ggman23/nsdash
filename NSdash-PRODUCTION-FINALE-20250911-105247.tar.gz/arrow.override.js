(function(){
  const THRESH_SINGLE = 4;   // >=4 ou <=-4 -> flèche simple (au lieu de 2)
  const THRESH_DOUBLE = 10;  // >=10 ou <=-10 -> double flèche
  
  function deltaToArrow(delta) {
    if (delta == null || isNaN(delta)) return "→";
    const d = Number(delta);
    if (d >= THRESH_DOUBLE) return "↑↑";
    if (d <= -THRESH_DOUBLE) return "↓↓";
    if (d >= THRESH_SINGLE) return "↑";
    if (d <= -THRESH_SINGLE) return "↓";
    return "→";
  }
  
  window.deltaToArrow = deltaToArrow;
  window.trendArrowFromDelta = deltaToArrow;
  window.NSDASH = window.NSDASH || {};
  window.NSDASH.trendFromDelta = deltaToArrow;
})();
